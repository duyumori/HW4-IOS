import XCTest

final class BookExplorerUITests: XCTestCase {
    private let app = XCUIApplication()

    override func setUpWithError() throws {
        continueAfterFailure = false
        app.launch()
        XCTAssertTrue(app.tables["all-books"].waitForExistence(timeout: 10))
    }

    func testDemoInteractions() {
        let collection = app.collectionViews["popular-books"]
        collection.swipeLeft()
        collection.swipeRight()
        collection.cells["card-hobbit"].tap()
        XCTAssertTrue(app.alerts["The Hobbit"].exists)
        app.buttons["Close"].tap()
        XCTAssertTrue(app.staticTexts["12 books"].exists)
        let table = app.tables["all-books"]
        for _ in 0..<8 {
            if table.cells["row-1984"].isHittable { break }
            table.swipeUp()
        }
        table.cells["row-1984"].tap()
        XCTAssertTrue(app.alerts["1984"].exists)
        app.buttons["Close"].tap()
        table.cells["row-1984"].swipeLeft()
        app.buttons["Delete book"].tap()
        XCTAssertFalse(collection.cells["card-1984"].exists)
    }

    func testDeleteAll() {
        let rows = app.tables["all-books"].cells.matching(NSPredicate(format: "identifier BEGINSWITH %@", "row-"))
        for _ in 0..<12 {
            rows.firstMatch.swipeLeft()
            app.buttons["Delete book"].tap()
        }
        XCTAssertTrue(app.staticTexts["No books left"].exists)
        XCTAssertEqual(app.collectionViews["popular-books"].cells.count, 0)
    }
}
